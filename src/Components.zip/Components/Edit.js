import React from "react";
import Information from "./Information";
import { Button } from "@material-ui/core";
const Edit = (props) => {
  const { activeStep, setActiveStep } = props;
  const [isOpen, setIsOpen] = React.useState(false);
  const onSubmit=()=>{
      setActiveStep(activeStep+1);
  }
  const handleClick = () => {
    setIsOpen(!isOpen);
  };
  return (
    <div>
      {isOpen ? (
        <Information activeStep={activeStep} setActiveStep={setActiveStep} />
      ) : null}

      <Button variant="contained" color="secondary" onClick={handleClick}>
        {isOpen ? "Cancel" : "Edit"}
      </Button>
      <Button variant="contained" color="primary" onClick={onSubmit} >Submit</Button>
    </div>
  );
};

export default Edit;
